$(function(){

	//将内容插入到body开始处，页面加载完毕后自动展开
	$('body').prepend("<div class='slide-ads'><img src='http://file.ljcd.gov.cn/uploadfile/2016/0623/20160623081622129.jpg'></div>");
	$('.slide-ads').slideDown(1500,function(){
		$('.slide-ads').append("<a href='javascript:;' class='up'></a>");									  
	});	
	//设置延时函数
	function adsUp(){
		$('.slide-ads').animate({
			height:'0'						 
		},1000);	
	}
	//五秒钟后自动收起
	var t = setTimeout(adsUp,5000);
	//点击收起
	$('.slide-ads a.up').live('click',function(){
		clearTimeout(t);
		$('.slide-ads').animate({
			height:'0'						 
		});	 
	});	
});